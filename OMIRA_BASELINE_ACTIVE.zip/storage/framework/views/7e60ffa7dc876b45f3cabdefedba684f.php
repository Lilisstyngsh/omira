<!doctype html>
<html lang="id">

<head>
    <meta charset="utf-8">
    <style>
        @page {
            margin: 9mm 7mm;
            size: A4 portrait;
        }

        body {
            font-family: DejaVu Sans, sans-serif;
            color: #161616;
            font-size: 7px;
        }

        table {
            border-collapse: collapse;
            table-layout: fixed;
            width: 100%;
        }

        .header td {
            border: 1px solid #444;
            height: 49px;
            vertical-align: middle;
            padding: 5px;
        }

        .header .side {
            width: 24%;
            text-align: center;
        }

        .header .title {
            width: 52%;
            text-align: center;
            font-size: 14px;
            font-weight: bold;
        }

        .logo {
            max-width: 100%;
            max-height: 38px;
        }

        .metadata {
            margin: 0;
            padding: 8px 7px 10px;
            line-height: 1.7;
        }

        .outer-frame {
            border: 1.2px solid #333;
            width: 100%;
            border-collapse: collapse;
        }

        .outer-frame>tbody>tr>td {
            border: 0;
            padding: 4px;
            vertical-align: top;
        }

        .form-frame {
            border: 0;
            margin-top: 5px;
        }

        .grid {
            border: 0;
            width: 100%;
        }

        .grid th,
        .grid td {
            border: 1px solid #555;
            padding: 2px 0.5px;
            word-wrap: break-word;
        }

        .grid th {
            text-align: center;
            font-weight: bold;
        }

        .grid .section {
            font-size: 9px;
        }

        .grid .sep {
            border: none !important;
            background: white !important;
            width: 2%;
            padding: 0;
        }

        .grid td.model,
        .grid td.num {
            text-align: center;
        }

        .grid td.num {
            white-space: nowrap;
            font-size: 6.5px;
            padding-left: 0;
            padding-right: 0;
        }

        .grid td.product {
            text-align: left;
        }

        .grid .summary td {
            font-weight: bold;
        }

        .grid .grand td {}

        .note {
            margin-top: 10px
        }

        .note-box {
            border: 1px solid #555;
            height: 40px;
            margin-top: 4px;
        }

        .signature {
            margin-top: 10px
        }

        .signature td {
            border: 1px solid #555;
            text-align: center;
            height: 20px
        }

        .signature .blank {
            height: 45px;
            vertical-align: middle;
            line-height: 1.6
        }
    </style>
</head>

<body>
    <table class="outer-frame">
        <tr>
            <td>
                <table class="header">
                    <tr>
                        <td class="side">
                            <?php if($logoData): ?>
                                <img class="logo" src="<?php echo e($logoData); ?>">
                            <?php else: ?>
                                <b>AISIN</b>
                            <?php endif; ?>
                        </td>
                        <td class="title">FORM ORDER REPAIR BOX NG</td>
                        <td class="side" style="font-size:10px;font-weight:bold;overflow-wrap:anywhere">
                            <?php echo e($order->order_number); ?></td>
                    </tr>
                </table>
                <div class="form-frame">
                    <div class="metadata"><b>Diserahkan oleh:</b> <?php echo e($handedBy); ?><br><b>Hari, tanggal:</b>
                        <?php echo e($date); ?></div>
                    <?php
                        $categories = ['P', 'H', 'C', 'S'];
                        $grandBefore = array_fill_keys($categories, 0);
                        $grandAfter = array_fill_keys($categories, 0);
                        $byModel = collect($entries)->groupBy('model');
                    ?>
                    <table class="grid">
                        <colgroup>
                            <col style="width:12%">
                            <col style="width:29%">
                            <col style="width:2%">
                            <col style="width:2%">
                            <col style="width:2%">
                            <col style="width:2%">
                            <col style="width:2%">
                            <col style="width:12%">
                            <col style="width:29%">
                            <col style="width:2%">
                            <col style="width:2%">
                            <col style="width:2%">
                            <col style="width:2%">
                        </colgroup>
                        <thead>
                            <tr>
                                <th colspan="6" class="section">PENYERAHAN USER</th>
                                <th class="sep" rowspan="3"></th>
                                <th colspan="6" class="section">KONFIRMASI PENGEMBALIAN OMD</th>
                            </tr>
                            <tr>
                                <th rowspan="2">Model</th>
                                <th rowspan="2">Produk</th>
                                <th colspan="4">Jenis NG &amp; Qty</th>
                                <th rowspan="2">Model</th>
                                <th rowspan="2">Produk</th>
                                <th colspan="4">Jenis NG &amp; Qty</th>
                            </tr>
                            <tr>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ng): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <th><?php echo e($ng); ?></th>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ng): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <th><?php echo e($ng); ?></th>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $byModel; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model => $modelEntries): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <?php  ?>
                                <?php $__currentLoopData = $modelEntries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entryIndex => $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <?php if($entryIndex === 0): ?>
                                            <td class="model" rowspan="<?php echo e(count($modelEntries)); ?>">
                                                <?php echo e($entry['model']); ?></td>
                                        <?php endif; ?>
                                        <td class="product">
                                            <?php echo e($entry['product']); ?></td>
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ng): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                $n = (int) ($entry['before'][$ng] ?? 0);
                                                $grandBefore[$ng] += $n;
                                            ?>
                                            <td class="num"><?php echo e($n ?: ''); ?></td>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <td class="sep"></td>
                                        <?php if($entryIndex === 0): ?>
                                            <td class="model" rowspan="<?php echo e(count($modelEntries)); ?>">
                                                <?php echo e($entry['model']); ?></td>
                                        <?php endif; ?>
                                        <td class="product">
                                            <?php echo e($entry['product']); ?></td>
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ng): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                $n = (int) ($entry['after'][$ng] ?? 0);
                                                $grandAfter[$ng] += $n;
                                            ?>
                                            <td class="num"><?php echo e($n ?: ''); ?></td>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="6" style="text-align:center">Tidak ada item Repair Order.</td>
                                    <td class="sep"></td>
                                    <td colspan="6" style="text-align:center">Tidak ada item Repair Order.</td>
                                </tr>
                            <?php endif; ?>
                            <tr class="summary">
                                <td colspan="2">SUB TOTAL</td>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ng): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <td class="num"><?php echo e($grandBefore[$ng] ?: ''); ?></td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <td class="sep">
                                </td>
                                <td colspan="2">SUB TOTAL</td>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ng): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <td class="num"><?php echo e($grandAfter[$ng] ?: ''); ?></td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                            <tr class="summary grand">
                                <td colspan="2">GRAND TOTAL</td>
                                <td class="num" colspan="4"><?php echo e(array_sum($grandBefore) ?: ''); ?></td>
                                <td class="sep"></td>
                                <td colspan="2">GRAND TOTAL</td>
                                <td class="num" colspan="4"><?php echo e(array_sum($grandAfter) ?: ''); ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
                <div class="note"><b>Catatan ketidaksesuaian:</b>
                    <div class="note-box"></div>
                </div>
                <table class="signature">
                    <tr>
                        <td>Diterima oleh (OMD)</td>
                        <td>Diserahkan oleh (User / Line)</td>
                    </tr>
                    <tr>
                        <td class="blank">
                            <?php if($isClosed && $omdApproval): ?>
                                <b>Diproses oleh OMD</b><br><?php echo e($omdApproval); ?>

                            <?php endif; ?>
                        </td>
                        <td class="blank">
                            <?php if($isClosed): ?>
                                <b>Dikonfirmasi elektronik</b><br><?php echo e($userApproval); ?><br><?php echo e($approvedAt); ?>

                            <?php endif; ?>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</body>

</html>
<?php /**PATH C:\laragon\www\omira\resources\views/user/orders/history-export-pdf.blade.php ENDPATH**/ ?>