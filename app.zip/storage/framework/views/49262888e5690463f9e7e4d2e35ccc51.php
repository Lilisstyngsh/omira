<div class="history-card history-pdf-preview">
    <div class="history-pdf-preview-heading">
        <h3>Preview PDF History Order</h3>
        <span>Pratinjau sebelum download</span>
    </div>
    <iframe
        src="<?php echo e($previewUrl); ?>"
        title="Preview PDF Order <?php echo e($order->order_number); ?>"
        loading="lazy"
        referrerpolicy="same-origin"></iframe>
    <div class="history-pdf-preview-footer">
        <a href="<?php echo e($downloadUrl); ?>" class="history-pdf-download"><i class="fa-regular fa-file-pdf" aria-hidden="true"></i> Download PDF</a>
    </div>
</div>
<?php /**PATH C:\laragon\www\omira\resources\views/partials/history-order-pdf-preview.blade.php ENDPATH**/ ?>