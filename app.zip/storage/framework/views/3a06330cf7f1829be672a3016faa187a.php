<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <style>
        @page { size: A4 landscape; margin: 11px 10px; }
        body { font-family: DejaVu Sans, sans-serif; font-size: 6.3px; color: #111; }
        .matrix { width: 100%; border-collapse: collapse; table-layout: fixed; }
        .report-page { page-break-after: always; }
        .report-page:last-child { page-break-after: auto; }
        .matrix th, .matrix td {
            border: .45px solid #555; padding: 2px 1px;
            text-align: center; vertical-align: middle;
            overflow-wrap: anywhere;
        }
        .matrix th { font-weight: bold; }
        .matrix thead { display: table-header-group; }
        .matrix .plant, .matrix .line, .matrix .model { font-weight: bold; }
        .matrix .produk { text-align: left; }
        .matrix .total, .matrix .grand-label { font-weight: bold; }
        .matrix .grand-label { white-space: nowrap; font-size: 5.5px; }
        .matrix .grand-empty { border: none !important; }
        .matrix .plantcol { width: 9%; }
        .matrix .linecol { width: 9%; }
        .matrix .modelcol { width: 11%; }
        .matrix .productcol { width: 12%; }
        .matrix .jeniscol { width: 4.5%; }
        .matrix .grandcol { width: 5.5%; }
        .matrix .grandtypecol { width: 5%; }
        .matrix tr { page-break-inside: avoid; }
        .annual { width: 100%; border-collapse: collapse; table-layout: fixed; font-size: 10pt; }
        .annual th, .annual td { border: .6px solid #777; padding: 9px 4px; text-align: center; }
        .annual .metric { width: 85px; font-weight: bold; text-align: left; }
        .annual-title { text-align: center; font-weight: bold; font-size: 13px; margin: 0 0 8px; }
        .annual-period { text-align: center; font-size: 9px; margin-bottom: 9px; }
    </style>
</head>
<body>
<?php if($isYearly): ?>
    <div class="annual-title">DATA REKAP REPAIR BOX - FY <?php echo e($startDate->year); ?></div>
    <div class="annual-period">April <?php echo e($startDate->year); ?> - Maret <?php echo e($endDate->year); ?></div>
    <div class="annual-period">Line: <?php echo e($selectedLineNames->isEmpty() ? 'Semua Line' : $selectedLineNames->implode(', ')); ?></div>
    <table class="annual">
        <thead><tr><th class="metric">INDIKATOR</th>
            <?php $__currentLoopData = $annualSummary; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><th><?php echo e(strtoupper($month['label'])); ?></th><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tr></thead>
        <tbody>
        <?php $__currentLoopData = ['target' => 'TARGET', 'order' => 'ORDER', 'finish' => 'FINISH', 'scrap' => 'SCRAP']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr><th class="metric"><?php echo e($label); ?></th>
                <?php $__currentLoopData = $annualSummary; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <td><?php echo e($month[$key] === null ? '' : number_format($month[$key], 0, ',', '.')); ?></td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php else: ?>
    <?php $__currentLoopData = $monthlyReports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
    <?php $__currentLoopData = $report['pages']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pageIndex => $pageRows): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="report-page"><table class="matrix">
        <colgroup>
            <col class="plantcol"><col class="linecol"><col class="modelcol"><col class="productcol">
            <col class="jeniscol">
            <?php $__currentLoopData = $report['days']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><col><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <col class="grandcol"><col class="grandtypecol">
        </colgroup>
        <thead>
            <tr>
                <th rowspan="2">PLANT</th>
                <th rowspan="2">LINE</th>
                <th rowspan="2">MODEL</th>
                <th rowspan="2">PRODUK</th>
                <th rowspan="2"></th>
                <th colspan="<?php echo e(count($report['days'])); ?>">Bulan : <?php echo e($report['range_label']); ?></th>
                <th rowspan="2" class="grand-empty"></th><th rowspan="2" class="grand-empty"></th>
            </tr>
            <tr>
                <?php $__currentLoopData = $report['days']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <th><?php echo e($date['header']); ?></th>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $pageRows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php $__currentLoopData = $plant['lines']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lineIndex => $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $line['models']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modelIndex => $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $model['products']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productIndex => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $__currentLoopData = ['order' => 'NG', 'ok' => 'OK', 'scrap' => 'Scrap']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $isLast = $loop->last && $loop->parent->last &&
                                        $loop->parent->parent->last && $loop->parent->parent->parent->last &&
                                        $loop->parent->parent->parent->parent->last && $loop->parent->parent->parent->parent->parent->last;
                                ?>
                                <tr>
                                    <?php if($lineIndex === 0 && $modelIndex === 0 && $productIndex === 0 && $key === 'order'): ?>
                                        <td rowspan="<?php echo e($plant['rowspan']); ?>" class="plant"><?php echo e($plant['name']); ?></td>
                                    <?php endif; ?>
                                    <?php if($modelIndex === 0 && $productIndex === 0 && $key === 'order'): ?>
                                        <td rowspan="<?php echo e($line['rowspan']); ?>" class="line"><?php echo e($line['name']); ?></td>
                                    <?php endif; ?>
                                    <?php if($productIndex === 0 && $key === 'order'): ?>
                                        <td rowspan="<?php echo e($model['rowspan']); ?>" class="model"><?php echo e($model['name']); ?></td>
                                    <?php endif; ?>
                                    <?php if($key === 'order'): ?>
                                        <td rowspan="3" class="produk"><?php echo e($product['produk']); ?></td>
                                    <?php endif; ?>
                                    <td><?php echo e($label); ?></td>
                                    <?php $__currentLoopData = $report['days']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php $amount = (int) ($product['daily'][$date['key']][$key] ?? 0); ?>
                                        <td><?php echo e($amount > 0 ? number_format($amount, 0, ',', '.') : ''); ?></td>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($isLast): ?>
                                        <td colspan="2" class="grand-label">GRAND TOTAL</td>
                                    <?php else: ?>
                                        <td class="grand-empty"></td><td class="grand-empty"></td>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="5">Tidak ada produk</td><td colspan="<?php echo e(count($report['days'])); ?>"></td><td colspan="2" class="grand-label">GRAND TOTAL</td></tr>
            <?php endif; ?>
            <?php if($loop->last): ?>
            <?php $__currentLoopData = ['order' => 'NG', 'ok' => 'OK', 'scrap' => 'Scrap']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="total">
                    <?php if($loop->first): ?><td rowspan="3" colspan="4">TOTAL</td><?php endif; ?>
                    <td><?php echo e($label); ?></td>
                    <?php $__currentLoopData = $report['days']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $amount = (int) ($report['grandDaily'][$date['key']][$key] ?? 0); ?>
                        <td><?php echo e($amount > 0 ? number_format($amount, 0, ',', '.') : ''); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <td><?php echo e(number_format(collect($report['days'])->sum(fn ($d) => (int) ($report['grandDaily'][$d['key']][$key] ?? 0)), 0, ',', '.')); ?></td>
                    <td><?php echo e($label); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
        </tbody>
    </table></div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
</body>
</html>
<?php /**PATH C:\laragon\www\omira\resources\views/omd/recap/pdf.blade.php ENDPATH**/ ?>