<?php if($historyType === 'order'): ?>
    <?php
        $rows = $document->decisions->isNotEmpty() ? $document->decisions : $document->items;
        $canExport = $document->items->isNotEmpty();
        $hasNoDecision = $rows->contains(fn ($item) => isset($item->decision) && $item->decision === 'no');
    ?>
    <div class="ab-history-modal-content" data-modal-title="Detail Order Scrap">
        <?php if($canExport): ?>
            <div class="ab-modal-actions">
                <a href="<?php echo e(route('user.additional-box.export', [$document, 'pdf'])); ?>" class="ab-export-btn pdf">
                    <i class="fa-solid fa-file-pdf" aria-hidden="true"></i> PDF
                </a>
                <a href="<?php echo e(route('user.additional-box.export', [$document, 'excel'])); ?>" class="ab-export-btn excel">
                    <i class="fa-solid fa-file-excel" aria-hidden="true"></i> Excel
                </a>
            </div>
        <?php endif; ?>

        <section class="ab-modal-card">
            <div class="ab-modal-table-wrap">
                <table class="ab-modal-table">
                    <colgroup>
                        <col style="width:15%">
                        <col style="width:14%">
                        <col style="<?php echo e($hasNoDecision ? 'width:24%' : 'width:29%'); ?>">
                        <col style="width:13%">
                        <col style="<?php echo e($hasNoDecision ? 'width:13%' : 'width:29%'); ?>">
                        <?php if($hasNoDecision): ?>
                            <col style="width:21%">
                        <?php endif; ?>
                    </colgroup>
                    <thead>
                        <tr>
                            <th scope="col">No Order</th>
                            <th scope="col">Tanggal</th>
                            <th scope="col">Model – Produk</th>
                            <th scope="col">Scrap / Limit</th>
                            <th scope="col">Keputusan</th>
                            <?php if($hasNoDecision): ?>
                                <th scope="col">Alasan</th>
                            <?php endif; ?>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <?php $isOrder = !isset($item->decision) || $item->decision === 'yes'; ?>
                            <tr>
                                <td><?php echo e($document->document_number); ?></td>
                                <td><?php echo e($document->created_at->format('d-m-Y H:i')); ?></td>
                                <td class="ab-modal-model"><?php echo e($item->model_name ?: '—'); ?> – <?php echo e($item->product_name ?: '—'); ?></td>
                                <td class="ab-modal-center">
                                    <?php echo e(isset($item->scrap_qty) && isset($item->limit_qty) ? $item->scrap_qty . ' / ' . $item->limit_qty : '—'); ?>

                                </td>
                                <td>
                                    <span class="ab-decision-pill <?php echo e($isOrder ? 'yes' : 'no'); ?>"><?php echo e($isOrder ? 'Order' : 'Tidak'); ?></span>
                                </td>
                                <?php if($hasNoDecision): ?>
                                    <td class="ab-modal-reason"><?php echo e($isOrder ? '' : ($item->reason ?: '—')); ?></td>
                                <?php endif; ?>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr><td colspan="<?php echo e($hasNoDecision ? 6 : 5); ?>" class="ab-empty">Tidak ada data.</td></tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </section>

        <?php if($canExport): ?>
            <section class="ab-modal-card" aria-label="Preview PDF">
                <div class="ab-modal-card-header"><h3>Preview PDF</h3></div>
                <div class="ab-modal-preview">
                    <iframe class="ab-modal-preview-frame"
                        src="<?php echo e(route('user.additional-box.preview', $document)); ?>"
                        title="Preview PDF <?php echo e($document->document_number); ?>" loading="lazy"></iframe>
                    <p class="ab-modal-preview-fallback">Jika preview tidak tampil, <a
                            href="<?php echo e(route('user.additional-box.preview', $document)); ?>" target="_blank"
                            rel="noopener noreferrer">buka PDF di tab baru</a>.</p>
                </div>
            </section>
        <?php endif; ?>
    </div>
<?php else: ?>
    <div class="ab-history-modal-content" data-modal-title="Detail Reset Scrap">
        <section class="ab-modal-card">
            <div class="ab-modal-table-wrap">
                <table class="ab-modal-table ab-modal-table-reset">
                    <colgroup>
                        <col style="width:18%">
                        <col style="width:23%">
                        <col style="width:13%">
                        <col style="width:17%">
                        <col style="width:16%">
                        <col style="width:13%">
                    </colgroup>
                    <thead>
                        <tr>
                            <th scope="col">Tanggal</th>
                            <th scope="col">Model – Produk</th>
                            <th scope="col">Scrap / Limit</th>
                            <th scope="col">Keputusan</th>
                            <th scope="col">Alasan</th>
                            <th scope="col">Petugas OMD</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td><?php echo e($cycle->reset_at->format('d-m-Y H:i')); ?></td>
                            <td class="ab-modal-model"><?php echo e($cycle->product?->masterModel?->model ?: '—'); ?> – <?php echo e($cycle->product?->name ?: '—'); ?></td>
                            <td class="ab-modal-center"><?php echo e($cycle->reached_qty ?? 0); ?> / <?php echo e($cycle->limit_qty); ?></td>
                            <td><span class="ab-decision-pill reset">Reset oleh OMD</span></td>
                            <td class="ab-modal-reason"><?php echo e($cycle->reset_reason ?: '—'); ?></td>
                            <td><?php echo e($cycle->resetter?->name ?? 'OMD'); ?></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </section>
    </div>
<?php endif; ?>
<?php /**PATH C:\laragon\www\omira\resources\views/user/additional-box/partials/history-modal-content.blade.php ENDPATH**/ ?>