<?php $__env->startSection('title', 'Order Repair Box'); ?>
<?php $__env->startSection('header', 'Order Repair Box'); ?>

<?php $__env->startSection('content'); ?>
    <?php
        $indexRoute = 'user.orders.index';
        $showLineFilter = false;
    ?>
    <?php $completedOrders = $orders->getCollection()->where('status', 'completed')->count(); ?>

    <div class="repair-index">
        <div class="ri-heading">
            <h2>Daftar Order Repair</h2><a href="<?php echo e(route('user.orders.create')); ?>" class="ri-create"><i
                    class="fa-solid fa-plus" aria-hidden="true"></i>Buat Order</a>
        </div>
        <?php echo $__env->make('partials.repair-order-index-filter', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <div class="ri-table-wrap">
            <table class="ri-table">
                <colgroup>
                    <col style="width:6%">
                    <col style="width:14%">
                    <col style="width:22%">
                    <col style="width:9%">
                    <col style="width:12.25%">
                    <col style="width:12.25%">
                    <col style="width:12.25%">
                    <col style="width:12%">
                </colgroup>
                <thead>
                    <tr>
                        <th rowspan="2">No</th>
                        <th rowspan="2">Tanggal</th>
                        <th rowspan="2">No Order</th>
                        <th rowspan="2">Qty</th>
                        <th colspan="4">Status Proses</th>
                    </tr>
                    <tr>
                        <th class="process-cell">User Submit</th>
                        <th class="process-cell">Verifikasi OMD</th>
                        <th class="process-cell">Repair OMD</th>
                        <th class="process-cell">Serah Terima</th>
                    </tr>
                </thead>


                <tbody>

                    <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="ri-link-row" role="link" tabindex="0"
                            onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();this.click();}"
                            onclick="window.location='<?php echo e(route('user.orders.show', $order)); ?>'"
                            title="Klik untuk melihat detail order">

                            <td class="ri-count">
                                <?php echo e($orders->firstItem() + $index); ?>

                            </td>

                            <td class="ri-date">
                                <?php if($order->created_at): ?>
                                    <strong><?php echo e($order->created_at->format('d-m-Y')); ?></strong>
                                    <small><?php echo e($order->created_at->format('H:i')); ?></small>
                                <?php else: ?>
                                    -
                                <?php endif; ?>
                            </td>

                            <td class="ri-order-number">
                                <?php echo e($order->order_number); ?>

                            </td>

                            <td class="ri-qty">
                                <?php echo e(in_array($order->status, ['completed', 'revision_requested', 'confirmed'], true) ? (int) ($order->after_qty_sum ?? 0) : (int) ($order->before_qty_sum ?? $order->quantity)); ?>

                            </td>

                            
                            <td class="process-cell">

                                <span class="process-icon process-done" title="User sudah submit order">
                                    ✓
                                </span>

                            </td>

                            
                            <td class="process-cell">

                                <?php if(in_array($order->status, ['in_repair', 'completed', 'revision_requested', 'confirmed'])): ?>
                                    <span class="process-icon process-done" title="Order sudah diverifikasi OMD">
                                        ✓
                                    </span>
                                <?php else: ?>
                                    <span class="process-icon process-pending" title="Belum diverifikasi OMD">
                                        ✕
                                    </span>
                                <?php endif; ?>

                            </td>

                            
                            <td class="process-cell">

                                <?php if(in_array($order->status, ['completed', 'revision_requested', 'confirmed'])): ?>
                                    <span class="process-icon process-done" title="Repair OMD sudah selesai">
                                        ✓
                                    </span>
                                <?php elseif($order->status === 'in_repair'): ?>
                                    <span class="process-icon process-progress" title="Repair OMD sedang diproses">
                                        △
                                    </span>
                                <?php else: ?>
                                    <span class="process-icon process-pending" title="Repair OMD belum dimulai">
                                        ✕
                                    </span>
                                <?php endif; ?>

                            </td>

                            
                            <td class="process-cell">

                                <?php if($order->status === 'confirmed'): ?>
                                    <span class="process-icon process-done" title="Serah terima sudah selesai">
                                        ✓
                                    </span>
                                <?php elseif($order->status === 'revision_requested'): ?>
                                    <span class="process-icon process-progress"
                                        title="User meminta koreksi hasil repair dari OMD">
                                        △
                                    </span>
                                <?php elseif($order->status === 'completed'): ?>
                                    <span class="process-icon process-progress"
                                        title="Menunggu serah terima / konfirmasi User">
                                        △
                                    </span>
                                <?php else: ?>
                                    <span class="process-icon process-pending" title="Belum masuk tahap serah terima">
                                        ✕
                                    </span>
                                <?php endif; ?>

                            </td>

                        </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                        <tr>

                            <td colspan="8" class="ri-empty">
                                <div class="order-empty-text">
                                    <?php echo e(request()->hasAny(['start_date', 'end_date', 'search', 'line_id']) ? 'Tidak ada order sesuai filter.' : 'Belum ada Order Repair Box.'); ?>

                                </div>
                            </td>

                        </tr>
                    <?php endif; ?>

                </tbody>
            </table>
        </div>
        <div class="ri-pagination">
            <span class="ri-pagination-info">Menampilkan <?php echo e($orders->firstItem() ?? 0); ?>–<?php echo e($orders->lastItem() ?? 0); ?>

                dari <?php echo e($orders->total()); ?> order</span>
            <?php if($orders->lastPage() > 1): ?>
                <nav class="ri-pagination-links" aria-label="Halaman Order Repair">
                    <?php if($orders->onFirstPage()): ?>
                        <span class="ri-page disabled">Previous</span>
                    <?php else: ?>
                        <a class="ri-page" href="<?php echo e($orders->previousPageUrl()); ?>">Previous</a>
                    <?php endif; ?>
                    <?php if($orders->currentPage() > 3): ?>
                        <a class="ri-page" href="<?php echo e($orders->url(1)); ?>">1</a>
                        <?php if($orders->currentPage() > 4): ?>
                            <span class="ri-pagination-info">…</span>
                        <?php endif; ?>
                    <?php endif; ?>
                    <?php $__currentLoopData = $orders->getUrlRange(max(1, $orders->currentPage() - 2), min($orders->lastPage(), $orders->currentPage() + 2)); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $number => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e($url); ?>"
                            class="ri-page <?php echo e($number === $orders->currentPage() ? 'active' : ''); ?>"
                            <?php if($number === $orders->currentPage()): ?> aria-current="page" <?php endif; ?>><?php echo e($number); ?></a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php if($orders->currentPage() < $orders->lastPage() - 2): ?>
                        <?php if($orders->currentPage() < $orders->lastPage() - 3): ?>
                            <span class="ri-pagination-info">…</span>
                        <?php endif; ?>
                        <a class="ri-page" href="<?php echo e($orders->url($orders->lastPage())); ?>"><?php echo e($orders->lastPage()); ?></a>
                    <?php endif; ?>
                    <?php if($orders->hasMorePages()): ?>
                        <a class="ri-page" href="<?php echo e($orders->nextPageUrl()); ?>">Next</a>
                    <?php else: ?>
                        <span class="ri-page disabled">Next</span>
                    <?php endif; ?>
                </nav>
            <?php endif; ?>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\omira\resources\views/user/orders/index.blade.php ENDPATH**/ ?>