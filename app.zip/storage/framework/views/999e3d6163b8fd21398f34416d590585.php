<?php $__env->startSection('title', 'Riwayat Scrap Limit'); ?>
<?php $__env->startSection('header', 'Riwayat Scrap Limit'); ?>
<?php $__env->startSection('content'); ?>
<div style="background:#fff;border:1px solid #e2e8f0;border-radius:16px;padding:20px;">
    <h2 style="margin:0 0 15px;font-size:18px">Riwayat Scrap Limit User</h2>
    <div style="overflow-x:auto">
        <table style="width:100%;min-width:1050px;border-collapse:collapse;font-size:12px">
            <thead><tr style="background:#f3f7f4"><th>User</th><th>Plant / Line</th><th>Model / Produk</th><th>Aktual / Limit</th><th>Keputusan</th><th>Alasan User</th><th>Reset / Petugas</th><th>Aksi</th></tr></thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $cycles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cycle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr style="border-bottom:1px solid #e2e8f0">
                <td style="padding:12px"><?php echo e($cycle->user?->name); ?></td>
                <td><?php echo e($cycle->product?->masterModel?->line?->plant?->name); ?> / <?php echo e($cycle->line?->name); ?></td>
                <td><?php echo e($cycle->product?->masterModel?->model); ?> / <?php echo e($cycle->product?->name); ?></td>
                <td style="text-align:center"><?php echo e($cycle->reached_qty); ?> / <?php echo e($cycle->limit_qty); ?></td>
                <td style="text-align:center"><?php echo e($cycle->decision === 'yes' ? 'Ya' : ($cycle->decision === 'no' ? 'Tidak' : 'Belum dipilih')); ?></td>
                <td><?php echo e($cycle->decision_reason ?: '—'); ?></td>
                <td><?php echo e($cycle->reset_at ? $cycle->reset_at->format('d/m/Y H:i').' • '.($cycle->resetter?->name ?? '-') : 'Belum reset'); ?> <?php if($cycle->reset_reason): ?><div style="color:#64748b"><?php echo e($cycle->reset_reason); ?></div><?php endif; ?></td>
                <td style="padding:10px;min-width:190px">
                    <?php if(!$cycle->reset_at): ?>
                    <form method="POST" action="<?php echo e(route('omd.scrap-cycles.reset',$cycle)); ?>">
                        <?php echo csrf_field(); ?>
                        <input name="reason" required minlength="5" maxlength="1000" placeholder="Alasan reset" style="width:100%;padding:8px;border:1px solid #cbd5e1;border-radius:8px;margin-bottom:6px">
                        <button style="background:#347554;color:#fff;border:0;border-radius:8px;padding:9px 12px;cursor:pointer">Reset ke Default</button>
                    </form>
                    <?php else: ?> — <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr><td colspan="8" style="text-align:center;padding:24px">Belum ada riwayat limit tercapai.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
    <div style="margin-top:14px"><?php echo e($cycles->links()); ?></div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\omira\resources\views/omd/scrap-limits/cycles.blade.php ENDPATH**/ ?>