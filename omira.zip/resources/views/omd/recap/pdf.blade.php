<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <style>
        @page { margin: 22px; }
        body { font-family: DejaVu Sans, sans-serif; color:#1f2937; font-size:10px; }
        h1 { margin:0 0 4px; font-size:18px; }
        .period { color:#64748b; margin-bottom:14px; }
        .summary { width:100%; margin-bottom:14px; }
        .summary td { padding:8px 10px; border:1px solid #e5e7eb; }
        .summary strong { font-size:14px; }
        table.data { width:100%; border-collapse:collapse; }
        .data th, .data td { border:1px solid #d9dee7; padding:6px 7px; text-align:left; }
        .data th { background:#E7F1E9; color:#315E49; font-weight:bold; }
        .num { text-align:right !important; }
    </style>
</head>
<body>
    <h1>Rekap Repair Box</h1>
    <div class="period">Periode {{ $startDate->format('d-m-Y') }} s.d. {{ $endDate->format('d-m-Y') }} · Line: {{ $selectedLineNames->implode(', ') }}</div>

    <table class="summary">
        <tr>
            <td>Order<br><strong>{{ number_format($summary['order'], 0, ',', '.') }}</strong></td>
            <td>OK<br><strong>{{ number_format($summary['ok'], 0, ',', '.') }}</strong></td>
            <td>Scrap<br><strong>{{ number_format($summary['scrap'], 0, ',', '.') }}</strong></td>
        </tr>
    </table>

    <table class="data">
        <thead>
            <tr>
                <th>Plant</th>
                <th>Line</th>
                <th>Model</th>
                <th>Produk</th>
                <th>Jenis NG</th>
                <th>Total</th>
                <th>Tanggal</th>
            </tr>
        </thead>
        <tbody>
            @forelse ($rows as $row)
                <tr>
                    <td>{{ $row->plant }}</td>
                    <td>{{ $row->line }}</td>
                    <td>{{ $row->model ?? '-' }}</td>
                    <td>{{ $row->produk ?? '-' }}</td>
                    <td>{{ $row->jenis_ng }}</td>
                    <td class="num">{{ number_format($row->total, 0, ',', '.') }}</td>
                    <td>{{ \Illuminate\Support\Carbon::parse($row->tanggal)->format('d-m-Y') }}</td>
                </tr>
            @empty
                <tr><td colspan="7">Tidak ada data confirmed pada periode ini.</td></tr>
            @endforelse
        </tbody>
    </table>
</body>
</html>
