<!doctype html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <title>Data Master <?php echo e($scopeLabel); ?></title>
    <style>
        body { font-family: DejaVu Sans, sans-serif; font-size: 10px; }
        h2 { text-align: center; margin-bottom: 4px; }
        .subtitle { text-align: center; margin-bottom: 18px; color: #555; }
        table { width: 100%; border-collapse: collapse; }
        th, td { border: 1px solid #222; padding: 7px; }
        th { background: #f1f3f5; text-align: center; }
        .center { text-align: center; }
    </style>
</head>
<body>
    <h2>Data Master Model & Produk <?php echo e($scopeLabel); ?></h2>
    <div class="subtitle">OMD Order - Workshop Digital System</div>

    <table>
        <thead>
            <tr>
                <th width="10%">No</th>
                <th width="25%">Model</th>
                <th width="15%">No. Produk</th>
                <th>Produk</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $models; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $__empty_1 = true; $__currentLoopData = $model->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <?php if($index === 0): ?>
                            <td rowspan="<?php echo e($model->products->count()); ?>" class="center">
                                <?php echo e($model->number); ?>

                            </td>
                            <td rowspan="<?php echo e($model->products->count()); ?>">
                                <?php echo e($model->model); ?>

                            </td>
                        <?php endif; ?>
                        <td class="center"><?php echo e($index + 1); ?></td>
                        <td><?php echo e($product->name); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td class="center"><?php echo e($model->number); ?></td>
                        <td><?php echo e($model->model); ?></td>
                        <td class="center">-</td>
                        <td>Belum ada produk.</td>
                    </tr>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
</html>
<?php /**PATH C:\laragon\www\omira\resources\views\omd\master\exports\pdf.blade.php ENDPATH**/ ?>