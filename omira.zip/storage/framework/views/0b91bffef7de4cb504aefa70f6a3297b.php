<?php $__env->startSection('title', 'Request Additional Box'); ?>
<?php $__env->startSection('content'); ?>
<div style="background:white;padding:24px;border-radius:12px;overflow-x:auto">
    <h2>Form Request Additional Box</h2>
    <p><?php echo e($document->document_number); ?> · <?php echo e($document->created_at->format('d-m-Y H:i')); ?></p>
    <p><a class="btn btn-primary" href="<?php echo e(route('user.additional-box.export', [$document, 'pdf'])); ?>">Download PDF</a>
    <a class="btn btn-primary" href="<?php echo e(route('user.additional-box.export', [$document, 'excel'])); ?>">Download Excel</a>
    <a href="<?php echo e(route('user.additional-box.index')); ?>">Riwayat Permintaan</a> · <a href="<?php echo e(route('dashboard')); ?>">Dashboard</a></p>
    <table style="width:100%;border-collapse:collapse" border="1" cellpadding="12">
        <thead style="background:#195f7b;color:white"><tr><th>No.</th><th>Type Box</th><th>Marking</th><th>Purpose</th><th>Qty</th></tr></thead>
        <tbody><?php $__currentLoopData = $document->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><tr><td><?php echo e($loop->iteration); ?></td><td><?php echo e($item->model_name); ?> — <?php echo e($item->product_name); ?></td><td></td><td><?php echo e($document->purpose); ?></td><td><?php echo e($item->quantity); ?></td></tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\omira\resources\views\user\additional-box\show.blade.php ENDPATH**/ ?>