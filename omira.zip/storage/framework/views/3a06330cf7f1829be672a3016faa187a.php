<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <style>
        @page { margin: 22px; }
        body { font-family: DejaVu Sans, sans-serif; color:#1f2937; font-size:10px; }
        h1 { margin:0 0 4px; font-size:18px; }
        .period { color:#64748b; margin-bottom:14px; }
        .summary { width:100%; margin-bottom:14px; }
        .summary td { padding:8px 10px; border:1px solid #e5e7eb; }
        .summary strong { font-size:14px; }
        table.data { width:100%; border-collapse:collapse; }
        .data th, .data td { border:1px solid #d9dee7; padding:6px 7px; text-align:left; }
        .data th { background:#ede9fe; color:#4c1d95; font-weight:bold; }
        .num { text-align:right !important; }
    </style>
</head>
<body>
    <h1>Rekap Repair Box</h1>
    <div class="period">Periode <?php echo e($startDate->format('d-m-Y')); ?> s.d. <?php echo e($endDate->format('d-m-Y')); ?> · Line: <?php echo e($selectedLineNames->implode(', ')); ?></div>

    <table class="summary">
        <tr>
            <td>Order<br><strong><?php echo e(number_format($summary['order'], 0, ',', '.')); ?></strong></td>
            <td>OK<br><strong><?php echo e(number_format($summary['ok'], 0, ',', '.')); ?></strong></td>
            <td>Scrap<br><strong><?php echo e(number_format($summary['scrap'], 0, ',', '.')); ?></strong></td>
        </tr>
    </table>

    <table class="data">
        <thead>
            <tr>
                <th>Plant</th>
                <th>Line</th>
                <th>Model</th>
                <th>Produk</th>
                <th>Jenis NG</th>
                <th>Total</th>
                <th>Tanggal</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td><?php echo e($row->plant); ?></td>
                    <td><?php echo e($row->line); ?></td>
                    <td><?php echo e($row->model ?? '-'); ?></td>
                    <td><?php echo e($row->produk ?? '-'); ?></td>
                    <td><?php echo e($row->jenis_ng); ?></td>
                    <td class="num"><?php echo e(number_format($row->total, 0, ',', '.')); ?></td>
                    <td><?php echo e(\Illuminate\Support\Carbon::parse($row->tanggal)->format('d-m-Y')); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="7">Tidak ada data confirmed pada periode ini.</td></tr>
            <?php endif; ?>
        </tbody>
    </table>
</body>
</html>
<?php /**PATH C:\laragon\www\omira\resources\views/omd/recap/pdf.blade.php ENDPATH**/ ?>