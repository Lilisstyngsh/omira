<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <style>
        @page { margin: 15px 15px 18px; }
        body { font-family: DejaVu Sans, sans-serif; font-size: 7px; color: #24332b; }
        .title { text-align: center; font-size: 13px; font-weight: bold; margin: 0 0 3px; }
        .period { text-align: center; font-size: 8px; margin-bottom: 10px; }
        .month-heading { text-align: center; font-weight: bold; font-size: 10px; margin: 8px 0; }
        .month-section { page-break-after: always; }
        .month-section:last-child { page-break-after: auto; }
        .matrix { width: 100%; border-collapse: collapse; table-layout: auto; }
        .matrix th, .matrix td { border: 0.5px solid #748379; padding: 2px 1px; text-align: center; vertical-align: middle; overflow-wrap: break-word; }
        .matrix thead th { background: #e5eee8; font-weight: bold; }
        .matrix .group { font-weight: bold; background: #fff; }
        .matrix .product { text-align: left; padding-left: 5px; }
        .matrix .status { font-weight: normal; background: #fff; }
        .matrix .grandrow td { background: #d9e9df; font-weight: bold; }
        .matrix .empty { color: #64748b; padding: 15px; }
        .matrix .daycol { width: 18px; min-width: 18px; white-space: nowrap; padding: 2px 1px; }
        .matrix .totalcol { width: 45px; font-weight: bold; }
        .matrix .plantcol { width: 55px; }
        .matrix .linecol { width: 56px; }
        .matrix .modelcol { width: 57px; }
        .matrix .productcol { width: 74px; }
        .matrix .statuscol { width: 35px; }
        .matrix tbody tr { page-break-inside: avoid; }
    </style>
</head>
<body>
<?php $__currentLoopData = $monthlyReports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="month-section">
        <div class="title">DATA REKAP REPAIR BOX</div>
        <div class="period">Periode: <?php echo e($startDate->format('d-m-Y')); ?> s.d. <?php echo e($endDate->format('d-m-Y')); ?></div>
        <div class="period">Line: <?php echo e($selectedLineNames->isEmpty() ? 'Semua Line' : $selectedLineNames->implode(', ')); ?></div>
        <div class="month-heading">Bulan: <?php echo e($report['label']); ?></div>
        <table class="matrix">
            <thead>
                <tr>
                    <th rowspan="2" class="plantcol">PLANT</th>
                    <th rowspan="2" class="linecol">LINE</th>
                    <th rowspan="2" class="modelcol">MODEL</th>
                    <th rowspan="2" class="productcol">PRODUK</th>
                    <th rowspan="2" class="statuscol">JENIS</th>
                    <th colspan="<?php echo e(count($report['days'])); ?>">TANGGAL</th>
                    <th rowspan="2" class="totalcol">GRAND TOTAL</th>
                </tr>
                <tr>
                    <?php $__currentLoopData = $report['days']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <th class="daycol"><?php echo e($day); ?></th>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
            </thead>
            <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $report['plants']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php $__currentLoopData = $plant['lines']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lineIndex => $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $__currentLoopData = $line['models']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $modelIndex => $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $model['products']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $productIndex => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $__currentLoopData = ['order' => 'NG', 'ok' => 'OK', 'scrap' => 'Scrap']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <?php if($lineIndex === 0 && $modelIndex === 0 && $productIndex === 0 && $key === 'order'): ?>
                                    <td rowspan="<?php echo e($plant['rowspan']); ?>" class="group"><?php echo e($plant['name']); ?></td>
                                <?php endif; ?>
                                <?php if($modelIndex === 0 && $productIndex === 0 && $key === 'order'): ?>
                                    <td rowspan="<?php echo e($line['rowspan']); ?>" class="group"><?php echo e($line['name']); ?></td>
                                <?php endif; ?>
                                <?php if($productIndex === 0 && $key === 'order'): ?>
                                    <td rowspan="<?php echo e($model['rowspan']); ?>" class="group"><?php echo e($model['name']); ?></td>
                                <?php endif; ?>
                                <?php if($key === 'order'): ?>
                                    <td rowspan="3" class="product"><?php echo e($product['produk']); ?></td>
                                <?php endif; ?>
                                <td class="status"><?php echo e($label); ?></td>
                                <?php $__currentLoopData = $report['days']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $value = (int) ($product['daily'][$day][$key] ?? 0); ?>
                                    <td><?php echo e($value > 0 ? number_format($value, 0, ',', '.') : ''); ?></td>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <td><?php echo e($product['totals'][$key] ? number_format($product['totals'][$key], 0, ',', '.') : ''); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td class="empty" colspan="<?php echo e(count($report['days']) + 6); ?>">Tidak ada data Repair Box terkonfirmasi pada periode dan Line yang dipilih.</td></tr>
            <?php endif; ?>
            <?php $__currentLoopData = ['order' => 'NG', 'ok' => 'OK', 'scrap' => 'Scrap']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="grandrow">
                    <?php if($key === 'order'): ?>
                        <td colspan="4" rowspan="3">TOTAL</td>
                    <?php endif; ?>
                    <td><?php echo e($label); ?></td>
                    <?php $__currentLoopData = $report['days']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $value = (int) ($report['grandDaily'][$day][$key] ?? 0); ?>
                        <td><?php echo e($value > 0 ? number_format($value, 0, ',', '.') : ''); ?></td>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <td><?php echo e($report['grandTotals'][$key] ? number_format($report['grandTotals'][$key], 0, ',', '.') : ''); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</body>
</html>
<?php /**PATH C:\laragon\www\omira\resources\views\omd\recap\pdf.blade.php ENDPATH**/ ?>