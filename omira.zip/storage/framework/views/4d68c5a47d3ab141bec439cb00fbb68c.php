<table class="table">

    <thead>

        <tr>

            <th>
                Line
            </th>

            <th>
                Aksi
            </th>

        </tr>

    </thead>


    <tbody>

        <?php $__empty_1 = true; $__currentLoopData = $lines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $line): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr class="editable-line-row" data-line-id="<?php echo e($line->id); ?>"
                data-plant-id="<?php echo e($line->plant_id); ?>" data-name="<?php echo e($line->name); ?>"
                data-update-url="<?php echo e(route('omd.master.line.update', $line)); ?>"
                tabindex="0" aria-label="Edit nama Line <?php echo e($line->name); ?>">

                <td>

                    <div class="inline-name" data-editor="line">
                        <strong data-name-display><?php echo e($line->name); ?></strong>
                    </div>

                </td>

                <td>

                    <div class="action-group">

                        <form method="POST" action="<?php echo e(route('omd.master.line.destroy', $line->id)); ?>"
                            class="delete-line-form" style="display:inline">

                            <?php echo csrf_field(); ?>

                            <?php echo method_field('DELETE'); ?>

                            <button type="submit" class="master-delete" title="Hapus Line" aria-label="Hapus Line">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                    stroke-width="1.8" stroke-linecap="round" aria-hidden="true">
                                    <path d="m6 6 12 12M18 6 6 18" />
                                </svg>
                            </button>

                        </form>

                    </div>

                </td>

            </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

            <tr>

                <td colspan="2" class="text-center">
                    Belum ada Line
                </td>

            </tr>
        <?php endif; ?>

    </tbody>

</table>
<?php /**PATH C:\laragon\www\omira\resources\views\omd\master\partials\line_table.blade.php ENDPATH**/ ?>