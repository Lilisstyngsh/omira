<table>
    <thead>
        <tr>
            <th style="font-weight:bold;background:#f7f8fa;border:1px solid #000;">No</th>
            <th style="font-weight:bold;background:#f7f8fa;border:1px solid #000;">Model</th>
            <th style="font-weight:bold;background:#f7f8fa;border:1px solid #000;">No. Produk</th>
            <th style="font-weight:bold;background:#f7f8fa;border:1px solid #000;">Produk</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $models; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $__empty_1 = true; $__currentLoopData = $model->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <?php if($index === 0): ?>
                        <td rowspan="<?php echo e($model->products->count()); ?>" style="border:1px solid #000;">
                            <?php echo e($model->number); ?>

                        </td>
                        <td rowspan="<?php echo e($model->products->count()); ?>" style="border:1px solid #000;">
                            <?php echo e($model->model); ?>

                        </td>
                    <?php endif; ?>
                    <td style="border:1px solid #000;"><?php echo e($index + 1); ?></td>
                    <td style="border:1px solid #000;"><?php echo e($product->name); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td style="border:1px solid #000;"><?php echo e($model->number); ?></td>
                    <td style="border:1px solid #000;"><?php echo e($model->model); ?></td>
                    <td style="border:1px solid #000;">-</td>
                    <td style="border:1px solid #000;">Belum ada produk.</td>
                </tr>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH C:\laragon\www\omira\resources\views\omd\master\exports\excel.blade.php ENDPATH**/ ?>