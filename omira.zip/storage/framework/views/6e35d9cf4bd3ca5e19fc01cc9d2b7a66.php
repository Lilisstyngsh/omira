<?php $__env->startSection('title', 'Riwayat Request Additional Box'); ?>
<?php $__env->startSection('content'); ?>
<div style="background:white;padding:24px;border-radius:12px;overflow-x:auto">
    <h2>Riwayat Request Additional Box</h2>
    <p><a href="<?php echo e(route('dashboard')); ?>">Kembali ke Dashboard</a></p>
    <table style="width:100%;border-collapse:collapse" cellpadding="12">
        <thead><tr><th align="left">Nomor</th><th align="left">Tanggal</th><th>Produk</th><th>Form</th></tr></thead>
        <tbody><?php $__empty_1 = true; $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr style="border-top:1px solid #ddd"><td><?php echo e($document->document_number); ?></td><td><?php echo e($document->created_at->format('d-m-Y H:i')); ?></td><td align="center"><?php echo e($document->items_count); ?></td><td align="center"><a href="<?php echo e(route('user.additional-box.show', $document)); ?>">Lihat / Download</a></td></tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?><tr><td colspan="4">Belum ada permintaan additional box.</td></tr><?php endif; ?></tbody>
    </table>
    <?php echo e($requests->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\omira\resources\views\user\additional-box\index.blade.php ENDPATH**/ ?>